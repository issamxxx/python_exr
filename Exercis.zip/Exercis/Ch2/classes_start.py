#
# Example file for working with classes
#


def main():
 class myclass():
   def methode1(self):
     print("m1")
   def methode2(self,c):
     print("string ",c)  

 x=myclass()
 x.methode1()
 x.methode2("issam")
if __name__ == "__main__":
    main()
