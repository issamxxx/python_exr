#
# Example file for working with functions
#

# define a basic function
def func1():
    print(1)

# function that takes arguments
def func2(x,y):
    print(x , " " , y)

# function that returns a value
def func3(x):
    return x

# function with default value for an argument
def func4(x,y=2):
    result=0
    for i in range(y):
        result=result+x
    return result
#function with variable number of arguments
def func5(*x):
    result=0
    for i in x:
        result=result+i
    return result


print(func4(5))     

data=[1,2,3,4,5,6]
def Sum10th(data):
  sum=0
  for i,d in enumerate(data):
    if (i % 10 == 0): sum=sum+d
  return sum

print(Sum10th(data));  
