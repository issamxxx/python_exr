#
# Example file for working with loops
#

def main():
  x = 0
  
  # define a while loop
  #while (x < 5):
  #   print (x)
  #   x = x + 1

  # define a for loop
  for i in range(5,10):
     print(i)

  # use a for loop over a collection
  tab=["mon","tuesday","saturday"]
  for j in tab:
    print(j)
  # use the break and continue statements
  for n in range(5,10):
   if(n==6): break
   print(n)
   
  #using the enumerate() function to get index 
  
  
if __name__ == "__main__":
  main()
