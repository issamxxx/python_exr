#
# Example file for working with date information
#
from datetime import date, timedelta
from datetime import time
from datetime import datetime 

def main():
  ## DATE OBJECTS
  # Get today's date from the simple today() method from the date class
  today=date.today()
  print("date is : ",today)
  # print out the date's individual components
  print("individual components : ",today.month,today.year,today.day )
  
  # retrieve today's weekday (0=Monday, 6=Sunday)
  print("weekday :",today.weekday())
  days=["monday","tuesday","wednesday","thursday","friday","saturday","sunday"]
  print("the day is : ", days[today.weekday()])
  ## DATETIME OBJECTS
  # Get today's date from the datetime class
  t=datetime.now()
  print(t)
  

  
  # Get the current time
  x=datetime.time(t)
  print(x)
  d=datetime.date(t)
  print(d)
  
  dd=date.today()
  nn=date(dd.year,4,1)
  print((dd-nn).days)

today=date.today()
days=["Mon","Tue","Wed","Thu","Fri","Sat","Sun"]
print("Tomorrow will be "+days[(today.weekday()+1)%7])
  
if __name__ == "__main__":
  main();
  

#methode weekday-today-now-time-date  