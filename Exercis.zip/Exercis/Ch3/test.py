from datetime import date


today=date.today()
t=date(today.year,2,today.day+1)
days=["Mon","Tue","Wed","Thu","Fri","Sat","Sun"]
print(t)
print("Tomorrow will be "+days[(t.weekday()+1)%7])