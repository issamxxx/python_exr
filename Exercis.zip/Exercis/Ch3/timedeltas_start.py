#
# Example file for working with timedelta objects
#

from datetime import date
from datetime import time
from datetime import datetime
from datetime import timedelta
from time import strftime

# construct a basic timedelta and print it
print(timedelta(days=300,hours=23,minutes=0))

# print today's date
t=date.today()
print(t)

# print today's date one year from now
print("date one year from now is : " , t+timedelta(days=365))

# create a timedelta that uses more than one argument
print("date one year and one month from now is : ",t+timedelta(days=365,weeks=4))

# calculate the date 1 week ago, formatted as a string
x=t-timedelta(weeks=1)
print(x.strftime("%y - %b - %d"))

### How many days until April Fools' Day?
fools=date(t.year,4,1)
# use date comparison to see if April Fool's has already gone for this year
if(t>fools):
    print("april fools already went by %d days "% ((t-fools).days))
   
# if it has, use the replace() function to get the date for next year
    fools=fools.replace(year=t.year+1)
# Now calculate the amount of time until April Fool's Day  
    print("it's just ",((fools-t).days),"days until next april fools day !")
