#
# Example file for working with os.path module
#
import os 
from os import path 
import datetime
from datetime import date,time,timedelta,datetime
import time
from time import ctime

def main():
  # Print the name of the OS
   print(os.name)
  
  # Check for item existence and type
   print("tiem  existe :"+str(path.exists("os_start.txt")))
   print("item is a file "+str(path.isfile("os_start.txt")))
   print("item is a directory :"+str(path.isdir("os_start.txt")))
  
  # Work with file paths
   print("item's path "+str(path.realpath("os_start.txt")))
   print("item's path & name "+str(path.split(path.realpath("os_start.txt"))))
  
  # Get the modification time
   print(datetime.fromtimestamp(path.getmtime("os_start.txt")))
   t=time.ctime(path.getmtime("os_start.txt"))
   print(t)
  # Calculate how long ago the item was modified
   td=datetime.now()-datetime.fromtimestamp(path.getmtime("os_start.txt"))
   print("time "+str(td)+"\n")
   print("time in seconds "+str(td.total_seconds()))

  
if __name__ == "__main__":
  main()
