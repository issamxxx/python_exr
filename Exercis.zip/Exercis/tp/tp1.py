import math
prenom="ahmed"
age=20
majeur=True
compte_en_banque=20135.348
amis=["adil","badr","aziz"]
parents=("mohaned","fatima")
#exercice 2
x=15
print("Le nombre est "+str(x))
#exercice 3 
a,b,c=2,6,3
print(a ,"+", b ,"+", c )
#exercice 4:
   #prenom=0
if isinstance(prenom,str):
    print("La variable est une chaîne de caractères")
#exercice 5 :
phrase="bonjour tout le monde"
phrase=phrase.replace("bonjour","bonsoire")
print(phrase)     
#exercice 6:
exr6=["anne","julien","lucien","pierre","marie"]
exr6.sort()
print(*exr6, sep=", ")  
#exercice 7:
rayon=float(input("enter value : "))
volume=(4*math.pi)*math.pow(rayon,3) 
print(round(volume,2))   